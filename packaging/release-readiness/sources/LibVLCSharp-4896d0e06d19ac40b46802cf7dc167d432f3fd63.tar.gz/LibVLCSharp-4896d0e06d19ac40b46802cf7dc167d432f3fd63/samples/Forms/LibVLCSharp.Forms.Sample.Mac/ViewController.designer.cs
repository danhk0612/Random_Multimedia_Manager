﻿// WARNING
//
// This file has been generated automatically by Xamarin Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using Foundation;

namespace LibVLCSharp.Forms.Sample.Mac
{
    [Register("ViewController")]
    partial class ViewController
    {
        void ReleaseDesignerOutlets()
        {
        }
    }
}
