﻿using LibVLCSharp.Platforms.Windows;
using Windows.UI.Xaml.Controls;

namespace LibVLCSharp.UWP.Sample
{
    /// <summary>
    /// The main page of the application
    /// </summary>
    public sealed partial class MainPage : Page
    {
        /// <summary>
        /// Initializes a new instance of <see cref="MainPage"/> class
        public MainPage()
        {
            InitializeComponent();
            ViewModel = new MainViewModel();
        }

        /// <summary>
        /// Gets the view model.
        /// </summary>
        public MainViewModel ViewModel { get; }

        private void VideoView_Initialized(object sender, InitializedEventArgs e)
        {
            ViewModel.InitializedCommand.Execute(e);
        }
    }
}
